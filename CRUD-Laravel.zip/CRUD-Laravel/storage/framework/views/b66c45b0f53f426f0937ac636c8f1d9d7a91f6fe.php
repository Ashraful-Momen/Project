


<?php $__env->startSection('title'); ?>
Home Page

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page'); ?>
<section >
  <div class="container  ">
    <div class="row col-6 mx-auto">
      <div class="  border border-primary rounded mt-2 bg-warning">
        <p class="text-lg text-warning"><?php echo e(Session::get('msg')); ?></p>
        <h1>Student Registration</h1>
        <form action="<?php echo e(url('/updateData/'.$editdata->id )); ?>" method="POST" class="  " enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <div class="form-outline mb-4">
                <label class="form-label" for="name">Name:</label>
                <input type="text" name='name' id="name" class="form-control" value="<?php echo e($editdata->name); ?>"/>
                
              </div>
            <!-- Email input -->
            <div class="form-outline mb-4">
              <label class="form-label" for="email">Email address</label>
              <input type="email" name='email'id="email" class="form-control" value="<?php echo e($editdata->email); ?>"/>
              
            </div>
          
          <div class="form-outline mb-4">
            <label class="form-label" for="phone">Phone</label>
            <input type="string" id="phone" name='phone'class="form-control" value="<?php echo e($editdata->phone); ?>"/>
            
          </div>
            <!-- Password input -->
            <div class="form-outline mb-4">
                <label class="form-label" for="password">Password</label>
              <input type="password" id="password" name='password'class="form-control" value="<?php echo e($editdata->password); ?>"/>
              
            </div>
            
            <div class="form-outline mb-4">
                <input type="file" id="file" name='file'class="form-control"  value="<?php echo e($editdata->file); ?>"/>
                <label class="form-label" for="file">File</label>
              </div>
          
            <!-- 2 column grid layout for inline styling -->
            <div class="row mb-4">
              <div class="col d-flex justify-content-center">
                <!-- Checkbox -->
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
                  <label class="form-check-label" for="form1Example3"> Remember me </label>
                </div>
              </div>
          
              <div class="col">
                <!-- Simple link -->
                <a href="#!">Forgot password?</a>
              </div>
            </div>
          
            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block">Sign in</button>
          </form>
      </div>
    </div>
  </div>
 
  
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Adhiha\Downloads\Laravel-4\Laravel-4\resources\views/editdata.blade.php ENDPATH**/ ?>