<?php

use App\Http\Controllers\Frontend\DataReceiveController;
use App\Http\Controllers\Frontend\editdataController;
use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\PortalController;
use Illuminate\Support\Facades\Route;





Route::get('/',[HomeController::class,'index'])->name('home');

// Data Receive
Route::post('/',[DataReceiveController::class,'dataReceive'])->name('dataReceive');

// Data Show with portal page 
Route::get('/portal',[PortalController::class,'portal'])->name('portal');

//Data Edit : 

Route::get('/editdata/{id}',[PortalController::class,'editdata']);

// Update Data
Route::post('/updateData/{id}',[PortalController::class,'updateData'])->name('updateData');

//Delete Data 

Route::get('/deletedata/{id}',[PortalController::class,'deletedata']);