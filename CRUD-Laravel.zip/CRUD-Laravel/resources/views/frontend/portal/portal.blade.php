@extends('master')

@section('page')
<div class="container">
    <div class="row">
        <div class="col-12 mx-auto my-2  border border-primary rounded">
            <table class="table">
                <thead>
                  <tr>
                   
                    <th scope="col">Id</th>
                    <th scope="col">Status</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Password</th>
                    <th scope="col">Image</th>
                    <th scope="col" class="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach ($Portals as $data)
                  <tr>
                   
                        
                   
                    {{-- <th scope="row">ID</th>
                    <td>status</td>
                    <td>name</td>
                    <td>email</td>
                    <td>phone</td>
                    <td>password</td>
                    <td>file</td> --}}
                    
            
                    <th scope="row">{{$data->id}}</th>
                    <td>{{$data->status}}</td>
                    <td>{{$data->name}}</td>
                    <td>{{$data->email}}</td>
                    <td>{{$data->phone}}</td>
                    <td>{{$data->password}}</td>
                   
                    <td> <img width="50px" height="40px" class="rounded-circle border border-info" src="{{ asset($data->file) }}"> </td>
                    <td>
                        <button class="btn btn-{{$data->status ==1 ? 'danger' : 'primary'}} rounded-pill">On</button>
                        <a href="{{url('/editdata/'.$data->id)}}" class="btn btn-success rounded-pill">Edit</a>
                        <a href="{{url('/deletedata/'.$data->id)}}" class="btn btn-danger rounded-pill">Delete</a>
                       
                   </td>
                    
                  </tr>
                  @endforeach
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
@endsection