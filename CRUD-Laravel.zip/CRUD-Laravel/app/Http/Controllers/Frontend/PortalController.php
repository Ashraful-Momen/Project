<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Portals;
use Illuminate\Http\Request;

class PortalController extends Controller
{
    public function portal(Request $request){
        $Portals = Portals::all();
        return view('frontend.portal.portal',compact('Portals'));


        
    }
    public function editdata($id=null){
        $editdata= Portals::find($id);
        return view('editdata',compact('editdata'));
    }
    public function updateData(Request $request,$id){

        

        $portal =  Portals::find($id);
        $portal->name = "$request->name";
        $portal->email = "$request->email";
        $portal->phone = "$request->phone";
        $portal->password = "$request->password";

        $image = $request->file;
        // $folder = 'Student-img';
        $imageName=time().$image->getClientOriginalName();
        if($image){

            $image->move('portal_image', $imageName);
            $portal->file = 'portal_image'."/". $imageName;
        }
       
        $portal->save();
        return redirect()->route('home')->with('msg','Student Data Update!!!');
    }
    public function deletedata($id=null){
        $deleteData= Portals::find($id);
        $deleteData->delete();
       
        return redirect()->route('portal');


        



    }
}
