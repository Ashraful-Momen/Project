<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class editdataController extends Controller
{
    public function editdata(){
        return view('/editdata');
    }
}

